<%
	String redirectURL = "http://www.example.com/";
	response.sendRedirect(redirectURL);
	response.sendForward(redirectURL);
	return;
%>
 
 